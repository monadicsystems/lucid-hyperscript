module Main where

main :: IO ()
main = print "_hyperscript ftw!"
